#ToolEasy Installer# Python2 
#Tools By MarMu
#Face Book - Technology By MarMu
#Do not modify this tool 
#love u all :)
################  Gone Gyi; What r u looking for  ############################################################################

b="\033[1m"
u="\033[4m" 
bl="\033[30m"
r="\033[31m"
g="\033[32m"
bu="\033[34m"
m="\033[35m"
c="\033[36m"
w="\033[37m"
ec="\033[0m"
blue="\033[1;34m"
p="\033[1;36m"
red="\033[1;31m"
tes="\033[1;97m"
k="\033[1;93m"
t="\033[1;91m"
gt="\033[1;92m"
a="\033[1;96m"

import os,sys,time

def marmu():
     os.system("clear")
logo ="""
  \33[32;1m  aaaaaaaaaaaaaaaaaaaa  \33[93;1mM A R M U \33[0m\33[1;32m aaaaaaaaaaaaaaaaaaa  \33[0m     
     \33[36;1mCREATION  \33[91;1m<=> \33[1;95;3mMarMu \33[0m
     \33[36;1mFACEBOOK  \33[91;1m<=> \33[1;95;3mTechonology By MarMu \33[0m
     \33[36;1mINSTAGRAM \33[91;1m<=> \33[1;95;3mHtet Aung \33[0m
     \33[36;1mGITHUB    \33[91;1m<=> \33[1;95;3mhttps://github.com/MarMu    \033[0m
  \33[32;1m  aaaaaaaaaaaaaaaaaaaa  \33[93;1m3 IN 1 \33[0m\33[1;32m aaaaaaaaaaaaaaaaaaa \33[0m    
"""

print logo

CorrectUsername = "MarMu"
CorrectPassword = "BaByDragoN"


loop = 'true'
while (loop == 'true'):
    username = raw_input("\033[1;96m[+] \x1b[1;97mTOOL USERNAME \x1b[1;96m>>>> ")
    if (username == CorrectUsername):
    	password = raw_input("\033[1;96m[+] \x1b[1;97mTOOL PASSWORD \x1b[1;96m>>>> ")
        if (password == CorrectPassword):
            print "Login Secessful ;) "
            loop = 'false'
        else:
            print "\033[1;91mLogin Failed!! \033[1;92mFollow my FB Page to get the correct password"
            os.system('xdg-open https://www.facebook.com/marmu.007')

    else:
        print "\033[1;91mWrong Username ! \033[1;92mFollow My FB Page & Telegram Channel to get the correct username"
        os.system('xdg-open https://m.facebook.com/marmu.007')

def login():
	os.system('clear')
def main():
    time.sleep(1)
    marmu()
    print ('\033[1;35m')
    os.system ('toilet -F border:gay 3 IN 1')
    print'    \33[36;1m\33[1;32mVersion \33[34;1m1.0 \33[0m'

    print'\33[36;1m+ \33[33;3;1mAUTHOR    \33[31;1m=> \33[1;36mMarMu '
    print'\33[36;1m+ \33[33;3;1mFACEBOOK  \33[31;1m=> \33[1;36mTechonology By MarMu '
    print'\33[36;1m+ \33[33;3;1mINSTAGRAM \33[31;1m=> \33[1;36mHtet Aung '
    print'\33[36;1m+ \33[33;3;1mGITHUB    \33[31;1m=> \33[1;36mhttps://github.com/MarMu \33[0m'   
    print'\33[40;1m  aaaaaaaaaaaaaaaaaaaa  \33[92;1m3 IN 1 \33[0m\33[1;40m aaaaaaaaaaaaaaaaaaa  '     

    print'\33[36;1m+ \33[36;1m{\33[37;1m1\33[36;1m} \33[35;3;1mOLD ACC AUTO CRACKING      \33[0m'
    print'\33[36;1m+ \33[36;1m{\33[37;1m2\33[36;1m} \33[35;3;1mFB ACC AUTO HACK (2009-2016)  \33[0m'
    print'\33[36;1m+ \33[36;1m{\33[37;1m3\33[36;1m} \33[35;3;1mACTIVR ACC CRACKING  {Login}  \33[0m'
    print'\33[36;1m+ \33[36;1m{\33[37;1m4\33[36;1m} \33[35;3;1mCONTACT TO MARMU           \33[0m'
    print'\33[36;1m+ \33[36;1m{\33[37;1m5\33[36;1m} \33[35;3;1mEXIT                \33[0m'
    print'\33[36;1m+\33[1;34m~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\33[36;1m+'
    print'\33[1;36m~ '
    print'\33[1;36m~ '
    gans = raw_input ('\033[1;36m{ \33[1;91mMARMU \33[36m}\33[1;97m=>>>\033[1;35m ')


#######################  Credit - Abdul Basit Minhas   ###############################
    if gans in ['1']:
        time.sleep(1)
        os.system('rm -rf fbc')
        os.system('git clone https://github.com/B4BY-D/fbc')
        marmu()
	time.sleep(2)
        print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
	marmu()
        os.system('cd fbc;python2 domains.py')
        os.system ('rm -rf fbc')
        sys.exit
        
        
#######################  Credit - Mr. ERROR  #######################
    if gans in ['2']:
        time.sleep(1)
        os.system('rm -rf oldcr3k')
        os.system ('git clone https://github.com/B4BY-D/oldcr3k')
        marmu()
	time.sleep(2)
	print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
	marmu()
        os.system('cd oldcr3k;python oldcr3k.py')
        os.system('rm -rf oldcr3k')
        sys.exit
        os.system('rm -rf oldcr3k')
        
#########################  Credit - Tech ABM  #######################
    if gans in ['3']:
        time.sleep(1)
        os.system('rm -rf Abm-Pro')
        os.system('git clone https://github.com/Tech-abm/Abm-Pro')
        marmu()
	time.sleep(2)
        print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
        print ('you need FB token for this tool')
        time.sleep(3)
	marmu()
        os.system('cd Abm-Pro;python2 install.lxml')
        os.system ('rm -rf Abm-Pro')
        sys.exit
        
######################  Contact to MarMu. ################################
    if gans in ['4']:
        marmu()
	time.sleep(2)
	print'\33[1;33mlove \33[31;1myou \33[0;36mAll.......'
        marmu()
	os.system('xdg-open https://m.facebook.com/marmu.007')
####################### Exit Tool #########################################
    if gans in ['5']:
        print'Bye Bye (Gonge Gyi)!'
        time.sleep(2)
        exit()

    else:
        time.sleep(1)
        print (' Thanks For Using. . .')
        time.sleep(1)
        main()

main()
      
exit
